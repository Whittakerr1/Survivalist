Thanks for downloading my tileset! Hope it is convenient to use. 

If the Tiled map doesn't work, please check if it directs to the path of the TGOD_CreepyCrypt.png. 
Some of the shadows are a bit clunky since I've used some old rule workflow for tiled, hence some manual revision may be necessary.

If you're going to use it, crediting me would be much appreciated (SubtleCorpse).

Follow me on socials:

subtlecorpse.bsky.social
x.com/SubtleCorpse
reddit.com/user/SubtleCorpse/

